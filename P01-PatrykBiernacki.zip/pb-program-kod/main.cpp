#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

//GLOWNA FUNKCJA
vector<vector<int>> znajdzNajdluzszeMalejace(const vector<int>& tablica) {
    vector<vector<int>> wyniki;
    if (tablica.empty()) return wyniki;

    int n = tablica.size();
    int maxDl = 0;
    int i = 0;

    while (i < n) {
        int j = i + 1;

        // Szukamy koncaa malejacego fragmentu (tab[j] < tab[j-1])
        while (j < n && tablica[j] < tablica[j-1]) {
            j++;
        }

        int obecnaDl = j - i;

        // Aktualizacja wynikow jesli znaleziono dluzszy lub rowny podciag
        if (obecnaDl >= maxDl) {
            if (obecnaDl > maxDl) {
                maxDl = obecnaDl;
                wyniki.clear(); // Nowy rekord - czyscimy stare wyniki
            }
            // Kopiujemy podciag bezposrednio uzywajac iteratorow
            wyniki.push_back(vector<int>(tablica.begin() + i, tablica.begin() + j));
        }

        // Przeskakujemy przetworzony fragment
        i = j;
    }
    return wyniki;
}

// --- WYSWIETLANIE WYNIKOW ---
void wypiszWynik(const vector<int>& wejscie, const vector<vector<int>>& wynik) {
    cout << "Wejscie: [ ";
    for (int x : wejscie) cout << x << " ";
    cout << "]\n";

    if (wynik.empty()) {
        cout << " -> Brak wynikow.\n";
    } else {
        cout << " -> Znaleziono " << wynik.size() << " najdluzsze (dl: " << wynik[0].size() << "):\n";
        for (const auto& podciag : wynik) {
            cout << "    [ ";
            for (int x : podciag) cout << x << " ";
            cout << "]\n";
        }
    }
    cout << "------------------------------------------------\n";
}

// --- OBSLUGA PLIKOW ---
void testZPliku() {
    ifstream plikWe("dane.txt");
    if (!plikWe) {
        cout << "Blad: Nie mozna otworzyc dane.txt\n";
        return;
    }

    vector<int> dane;
    int liczba;
    while (plikWe >> liczba) {
        dane.push_back(liczba);
    }
    plikWe.close();

    vector<vector<int>> wynik = znajdzNajdluzszeMalejace(dane);

    ofstream plikWy("wynik.txt");
    if (plikWy) {
        plikWy << "Wyniki analizy:\n";
        for (const auto& podciag : wynik) {
            for (int x : podciag) plikWy << x << " ";
            plikWy << "\n";
        }
        cout << "Wyniki zapisano do wynik.txt\n";
    } else {
        cout << "Blad zapisu do pliku.\n";
    }
}

// --- MAIN ---
int main() {
    cout << "=== Wyszukiwanie malejacych podciagow ===\n\n";

    // 1. Testy automatyczne
    cout << "--- Testy wewnetrzne ---\n";

    vector<int> t1 = {-10, 5, 8, 1, -4, -4, 10, 3, -1, 1}; // Przyklad z zadania
    wypiszWynik(t1, znajdzNajdluzszeMalejace(t1));

    vector<int> t2 = {1, 2, 3, 4}; // Rosnacy
    wypiszWynik(t2, znajdzNajdluzszeMalejace(t2));

    vector<int> t3 = {5, 4, 3, 2}; // Caly malejacy
    wypiszWynik(t3, znajdzNajdluzszeMalejace(t3));

    vector<int> t4 = {}; // Pusty
    wypiszWynik(t4, znajdzNajdluzszeMalejace(t4));

    // 2. Obsluga plikow
    char wybor;
    cout << "Czy wczytac dane z pliku 'dane.txt'? (t/n): ";
    cin >> wybor;

    if (wybor == 't' || wybor == 'T') {
        testZPliku();
    }

    return 0;
}
